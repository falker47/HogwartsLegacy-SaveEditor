@echo off
setlocal
call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
echo VCToolsVersion=%VCToolsVersion%
echo WindowsSDKVersion=%WindowsSDKVersion%
where cl
where link
cl /Bv /nologo /std:c11 /O2 /MT /DNDEBUG /Brepro /I"..\..\source\hlsavetool\headers" /FIcommon.h "..\..\source\hlsavetool\src\hlsaves.c" "..\..\source\hlsavetool\src\oodle.c" /Fe:hlsaves.exe /link /Brepro /INCREMENTAL:NO
exit /b %errorlevel%
