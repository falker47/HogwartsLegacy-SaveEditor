# Reproduce the HL-02A converter fix

This is a LOCAL publication-candidate archive. No fork, tag or release was created by this task.
Proposed downstream version: 2.0.1-hl02a.1; this is not an upstream version claim.

Upstream source: https://github.com/gx570s/hlsavetool.git
Baseline: 1bab30e3f62a23e8687c2d4995356fd48949dd05 (v2.0.1)
Patched commit: 480059cb237724e8605505e62a4e516a58adbce3
Patch: candidate.patch (SHA-256 637419d05531e72e76f5ca61193d04dd2b0e039fa1e1c557d002d09ea0854a20).
Preserve LICENSE and Copyright (c) 2024 Katt.

Use the exact MSVC x64 toolchain identified in SOURCE.json. Install path used by scripts/build.cmd:
C:/Program Files (x86)/Microsoft Visual Studio/2019/BuildTools.
Compiler 19.29.30159.0, linker 14.29.30159.0, VCToolsVersion 14.29.30133, SDK 10.0.19041.0.
The script prints the versions; verify they match SOURCE.json. It is the unchanged HL-02A recipe.

Lay out the committed source at source/hlsavetool, this archive's script at scripts/build.cmd,
and create an empty build/rebuilt directory. Export the commit with core.autocrlf=false and
core.eol=lf to use canonical Git blob bytes, or check out the same commit.
From build/rebuilt run:

    cmd /d /c ../../scripts/build.cmd

The script initializes vcvars64.bat and runs:

    cl /Bv /nologo /std:c11 /O2 /MT /DNDEBUG /Brepro /I"../../source/hlsavetool/headers" /FIcommon.h "../../source/hlsavetool/src/hlsaves.c" "../../source/hlsavetool/src/oodle.c" /Fe:hlsaves.exe /link /Brepro /INCREMENTAL:NO

Expected hlsaves.exe: 153088 bytes, SHA-256 bdf28ae18dc5ecf049af37ca863085851f2cd0f5b22895f9637c5820c8d0f70e.
This exact binary was reproduced from committed LF sources as well as the original source bytes.
The known SDK C5105 warning is inherited from the baseline.

The runtime Oodle DLL is not part of this archive or the MIT source license.
The application's existing runtime dependency remains separate.

The archive uses ZIP_STORED, sorted file names, fixed 2026-09-28 00:00:00 timestamps and 0644 modes.
Its internal SHA256SUMS.txt covers every other member. Source identity is pinned by the full commit,
and the proposed release asset must also be pinned by its complete archive SHA-256.
