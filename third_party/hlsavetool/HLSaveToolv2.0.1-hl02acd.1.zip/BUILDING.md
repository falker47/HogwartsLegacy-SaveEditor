Use build-gcc.ps1 -Gcc <gcc.exe> -Source source -Output <new-output.exe>.
The exact compiler is MSYS2 UCRT64 GCC 13.1.0 Rev6. No Oodle DLL is included.
Windows 10/11 UCRT is required. Oodle is a separate user-provided runtime.
