#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

/* Return false for size overflow or allocation failure without modifying
 * the caller's pointer or capacity on failure. */
static bool ensure_chunk_capacity(unsigned char** result,
                                  size_t* capacity,
                                  size_t used,
                                  size_t appended) {
    if (used > SIZE_MAX - appended) return false;
    const size_t required = used + appended;
    if (required <= *capacity) return true;
    unsigned char* grown = (unsigned char*)realloc(*result, required);
    if (grown == NULL) return false;
    *result = grown;
    *capacity = required;
    return true;
}
