#include "oodle.h"

static const byte needle[] = {
  0x11, 0x00, 0x00, 0x00, // length
  0x52, 0x61, 0x77, 0x44, // RawDatabaseImage string
  0x61, 0x74, 0x61, 0x62,
  0x61, 0x73, 0x65, 0x49,
  0x6D, 0x61, 0x67, 0x65,
  0x00 // null terminator
};
const enum { needle_len = sizeof(needle) };

static const byte needle2[] = {
  0x12, 0x00, 0x00, 0x00, // length
  0x52, 0x61, 0x77, 0x45, // RawExclusiveImage string
  0x78, 0x63, 0x6C, 0x75,
  0x73, 0x69, 0x76, 0x65,
  0x49, 0x6D, 0x61, 0x67,
  0x65, 0x00 // null terminator
};
const enum { needle2_len = sizeof(needle2) };

void usage(const char* argv[]) {
    const char* basename = strrchr(argv[0], '\\');
    basename = basename != NULL ? basename + 1 : APPLICATION_IMAGE_NAME;
    printf_warning("Usage: %s [OPTION] input output [VERBOSE]\n [OPTION]\n  -d decompress converts new to old format\n  -c compress converts old to new format\n [VERBOSE]\n  -v prints additional info (optional)\n", basename);
}

/**
 * Parse a UProperty (RawDatabaseImage ArrayProperty) starting at *address.
 * Advances *address past all the fields it reads.
 * Returns a heap-allocated UProperty on success, or calls exit() on failure.
 */
UProperty* parse_uproperty(byte** address, bool verbose) {
    SAFE_ALLOC(UProperty, property);

    READ_FSTRING(property->name, *address);
    PRINT_FSTRING(property->name);

    READ_FSTRING(property->type, *address);
    PRINT_FSTRING(property->type);
    if (memcmp(property->type.data, RDI_UPROPERTY_TYPE, RDI_UPROPERTY_TYPE_LEN) != 0) {
        printf_error("Expected UProperty of type \"%s\" got \"%s\"", RDI_UPROPERTY_TYPE, (byte*)property->type.data);
        exit(EXIT_FAILURE);
    }

    COPY_MEMORY(*address, &property->length, sizeof(property->length));
    printf_verbose(verbose, "ArrayProperty value length: %llu bytes", property->length);

    SAFE_ALLOC(UArrayProperty, value);

    READ_FSTRING(value->type, *address);
    PRINT_FSTRING(value->type);
    if (memcmp(value->type.data, RDI_UPROPERTY_VALUE_TYPE, RDI_UPROPERTY_VALUE_TYPE_LEN) != 0) {
        printf_error("Expected UProperty data of type \"%s\" got \"%s\"", RDI_UPROPERTY_VALUE_TYPE, (byte*)value->type.data);
        exit(EXIT_FAILURE);
    }

    COPY_MEMORY(*address, &value->unknown, sizeof(value->unknown));
    COPY_MEMORY(*address, &value->size, sizeof(value->size));
    printf_verbose(verbose, "ByteProperty value length: %lu bytes", value->size);

    size_t size = sizeof(byte) * value->size;
    SAFE_ALLOC_SIZE(byte, data, size);
    COPY_MEMORY(*address, data, size);
    value->value = data;
    property->data = value;

    return property;
}

/**
 * Free a heap-allocated UProperty and its nested UArrayProperty + value.
 */
void free_uproperty(UProperty* property) {
    if (property == NULL) return;
    UArrayProperty* value = (UArrayProperty*)property->data;
    if (value != NULL) {
        free(value->value);
        free(value);
    }
    free(property);
}

/**
 * Verify that a decompressed UProperty begins with the SQLite magic string.
 * Prints an error and exits if the check fails.
 */
void validate_sqlite(UProperty* property, int index, const char* prop_name) {
    UArrayProperty* data = (UArrayProperty*)property->data;
    if (data->size < SQLITE_HEADER_SIGNATURE_LEN) {
        printf_error("%s#%d: is too small to contain a SQLite header (%lu bytes)", prop_name, index, data->size);
        exit(EXIT_FAILURE);
    }
    if (memcmp(data->value, SQLITE_HEADER_SIGNATURE, SQLITE_HEADER_SIGNATURE_LEN) != 0) {
        printf_error("%s#%d: does not start with \"%s\" -- not a valid SQLite database", prop_name, index, SQLITE_HEADER_SIGNATURE);
        exit(EXIT_FAILURE);
    }
    printf_verbose(true, "%s#%d: SQLite signature is OK", prop_name, index);
}

int main(const int argc, const char* argv[]) {
    printf("\nHL Save Tool: decompress/recompress Hogwarts Legacy save files.\n\n"
        "v1 by @katt:               https://github.com/topche-katt/hlsavetool\n"
        "v2 by @ifonlythatweretrue: https://github.com/gx570s/hlsavetool\n\n"
        "Report problems in the POSTS or BUGS tab on https://www.nexusmods.com/hogwartslegacy/mods/1983\n\n"
    );

    if (argc < 4) {
        usage(argv);
        exit(EXIT_FAILURE);
    }

    /** Set up terminal colours. */
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD mode;
    GetConsoleMode(hConsole, &mode);
    SetConsoleMode(hConsole, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);

    const char* command = argv[1];
    if (memcmp(command, COMMAND_DECOMPRESS, strlen(COMMAND_DECOMPRESS)) != 0
        && memcmp(command, COMMAND_COMPRESS, strlen(COMMAND_COMPRESS)) != 0
        ) {
        printf_error("Unknown command \"%s\"", command);
        usage(argv);
        exit(EXIT_FAILURE);
    }

    uint8_t command_decompress = memcmp(command, COMMAND_DECOMPRESS, strlen(COMMAND_DECOMPRESS));
    uint8_t command_compress = memcmp(command, COMMAND_COMPRESS, strlen(COMMAND_COMPRESS));

    FILE* fpin = NULL;
    const char* input_filename = argv[2];
    OPEN_FILE_WITH_ERROR_HANDLE(input_filename, "rb", fpin);

    FILE* fpout = NULL;
    const char* output_filename = argv[3];

    bool verbose = (argc == 5 && argv[4] != NULL) ? strcmp(VERBOSITY_FLAG, argv[4]) == 0 : false;

    printf("Trying to %s save file \"%s\"\n\n", command_compress == 0 ? "compress" : "decompress", input_filename);

    printf_verbose(verbose, "Input file: %s", input_filename);
    printf_verbose(verbose, "Output file: %s", output_filename);

    size_t file_size = 0;
    fseek(fpin, 0, SEEK_END);
    file_size = ftell(fpin);
    fseek(fpin, 0, SEEK_SET);
    printf_verbose(verbose, "Input file size: %llu bytes", file_size);

    size_t buffer_size = sizeof(byte) * file_size;
    printf_verbose(verbose, "Input file memory buffer size: %llu bytes", buffer_size);

    SAFE_ALLOC_SIZE(byte, buffer, buffer_size);
    const size_t read_size = fread(buffer, buffer_size, 1, fpin);
    if (read_size != 1 && (feof(fpin) || ferror(fpin))) {
        printf_error("Input file: %llu = fread(buffer, buffer_size, 1, fp); failed", read_size);
        return EXIT_FAILURE;
    }

    GvasHeader header;
    memcpy(&header, buffer, sizeof(header));

    if (header.signature != GVAS_HEADER_SIGNATURE) {
        printf_error("Invalid GVAS header signature, expected 0x%08X got 0x%08X", _byteswap_ulong(GVAS_HEADER_SIGNATURE), _byteswap_ulong(header.signature));
        return EXIT_FAILURE;
    }

    if (header.version != GVAS_HEADER_VERSION) {
        printf_error("Invalid GVAS header version, expected %d got %d", GVAS_HEADER_VERSION, header.version);
        return EXIT_FAILURE;
    }

    printf_verbose(verbose, "GVAS File Header:");
    printf_verbose(verbose, " Signature: 0x%08X", _byteswap_ulong(header.signature));
    printf_verbose(verbose, " Version: %d", header.version);
    printf_verbose(verbose, " Package: %d", header.package);
    printf_verbose(verbose, " Engine: %d.%d.%d (%lu)", header.engine.major, header.engine.minor, header.engine.patch, header.engine.changelist);

    /* ------------------------------------------------------------------ */
    /* Locate first RawDatabaseImage                                       */
    /* ------------------------------------------------------------------ */

    /* SEARCH_MEMORY mutates its memory/size arguments as it scans, so we
     * pass throwaway copies and keep buffer/buffer_size intact for later
     * offset arithmetic.                                                  */
    byte* scan1 = buffer;
    size_t scan1_size = buffer_size;
    byte* address1 = NULL;
    SEARCH_MEMORY(address1, scan1, scan1_size, needle, needle_len);

    if (address1 == NULL) {
        printf_error("Could not locate first \"RawDatabaseImage\" UProperty");
        exit(EXIT_FAILURE);
    }

    printf_verbose(verbose, "Address of Base: 0x%016llX", (uint64_t)buffer);
    printf_verbose(verbose, "Address of first RawDatabaseImage: 0x%016llX", (uint64_t)address1);

    /* head = everything before the first property */
    MemoryAddress head = {
      .address = buffer,
      .size = (size_t)(address1 - buffer)
    };
    printf_verbose(verbose, "Head address 0x%016llX and size %llu bytes", (uint64_t)head.address, head.size);

    /* Parse first property; address1 is advanced past it by parse_uproperty */
    printf_verbose(verbose, "--- Parsing first RawDatabaseImage ---");
    UProperty* property1 = parse_uproperty(&address1, verbose);

    uint32_t signature1 = 0;
    memcpy(&signature1, ((UArrayProperty*)property1->data)->value, 4);
    printf_verbose(verbose, "ByteProperty value signature: 0x%08X", _byteswap_ulong(signature1));

	// Detect old uncompressed format (only relevant when decompressing)
	if (command_decompress == 0 && signature1 == SQLITE_HEADER_SIGNATURE_UINT32) {
        printf_warning("Save file \"%s\" is already in uncompressed (old) format -- no decompression needed.", input_filename);
        fclose(fpin);
        free(buffer);
        free_uproperty(property1);
        exit(EXIT_SUCCESS);
    }

    size_t property1_total = property1->length + RDI_UPROPERTY_DATA_OFFSET;

    /* ------------------------------------------------------------------ */
    /* Locate second RawDatabaseImage (if present)                        */
    /* ------------------------------------------------------------------ */

    /* Search only within the remaining buffer after property1 */
    byte* remaining = buffer + head.size + property1_total;
    size_t remaining_size = buffer_size - head.size - property1_total;

    /* Again use throwaway copies so remaining/remaining_size stay valid   */
    byte* scan2 = remaining;
    size_t scan2_size = remaining_size;
    byte* address2 = NULL;
    SEARCH_MEMORY(address2, scan2, scan2_size, needle2, needle2_len);

    UProperty* property2 = NULL;
    MemoryAddress between = { .address = remaining, .size = 0 };
    MemoryAddress tail = { .address = remaining, .size = remaining_size };

    if (address2 != NULL) {
        printf_verbose(verbose, "Address of second RawExclusiveImage: 0x%016llX", (uint64_t)address2);

        /* between = bytes between end of property1 and start of property2.
         * Use the saved original `remaining` base, not the mutated scan2.  */
        between.size = (size_t)(address2 - remaining);
        printf_verbose(verbose, "Between segment: address 0x%016llX, size %llu bytes",
            (uint64_t)between.address, between.size);

        /* Parse second property */
        printf_verbose(verbose, "--- Parsing second RawExclusiveImage ---");
        property2 = parse_uproperty(&address2, verbose);

        uint32_t signature2 = 0;
        memcpy(&signature2, ((UArrayProperty*)property2->data)->value, 4);
        printf_verbose(verbose, "ByteProperty value signature: 0x%08X", _byteswap_ulong(signature2));

        /* parse_uproperty advanced address2 past the complete property.
         * RawExclusiveImage has a different name length from RawDatabaseImage. */
        tail.address = address2;
        tail.size = (size_t)((buffer + buffer_size) - address2);
    }
    else {
        printf_verbose(verbose, "No second RawExclusiveImage found; processing only the first");
    }

    printf_verbose(verbose, "Tail address 0x%016llX and size %llu bytes",
        (uint64_t)tail.address, tail.size);

    /* ------------------------------------------------------------------ */
    /* Process                                                             */
    /* ------------------------------------------------------------------ */

    printf_verbose(verbose, "Before processing with %s command", command);

    if (command_decompress == 0) {
        printf_verbose(verbose, "Decompressing first RawDatabaseImage...");
        decompress(property1, verbose);
        validate_sqlite(property1, 1, "RawDatabaseImage");

        if (property2 != NULL) {
            printf_verbose(verbose, "Decompressing second RawExclusiveImage...");
            decompress(property2, verbose);
            validate_sqlite(property2, 2, "RawExclusiveImage");
        }
    }

    if (command_compress == 0) {
        printf_verbose(verbose, "Compressing first RawDatabaseImage...");
        compress(property1, verbose);
        if (property2 != NULL) {
            printf_verbose(verbose, "Compressing second RawExclusiveImage...");
            compress(property2, verbose);
        }
    }

    /* ------------------------------------------------------------------ */
    /* Write output                                                        */
    /* ------------------------------------------------------------------ */

    printf_verbose(verbose, "Begin writing to output file: %s", output_filename);

    OPEN_FILE_WITH_ERROR_HANDLE(output_filename, "wb", fpout);
    WRITE_FILE_WITH_ERROR_HANDLE(fpout, head.address, head.size, 1);
    SERIALIZE_ARRAY_PROPERTY(property1, fpout);

    if (property2 != NULL) {
        if (between.size > 0) {
            WRITE_FILE_WITH_ERROR_HANDLE(fpout, between.address, between.size, 1);
        }
        SERIALIZE_ARRAY_PROPERTY(property2, fpout);
    }

    WRITE_FILE_WITH_ERROR_HANDLE(fpout, tail.address, tail.size, 1);

    printf_verbose(verbose, "Finished writing to output file: %s", output_filename);

    fclose(fpout);
    fclose(fpin);

    free(buffer);
    free_uproperty(property1);
    free_uproperty(property2);

    printf("\n");
    printf_success("Successfully %s to save file \"%s\"\n", command_compress == 0 ? "compressed" : "decompressed", output_filename);

    return EXIT_SUCCESS;
}

/**
 * Quick memmem() implementation that runs on Windows...
 */
void* memmem(const void* haystack, size_t haystack_len, const void* needle, const size_t needle_len) {
    if (haystack == NULL || needle == NULL || haystack_len == 0 || needle_len == 0 || haystack_len < needle_len) {
        return NULL;
    }

    for (const char* chr = haystack; haystack_len >= needle_len; ++chr, --haystack_len) {
        if (!memcmp(chr, needle, needle_len)) {
            return (void*)chr;
        }
    }

    return NULL;
}

/**
 * Print error message wrapper
 */
int printf_error(const char* format, ...) {
    va_list args;
    va_start(args, format);
    printf("\x1B[91m[Error] ");
    int result = vprintf(format, args);
    printf(".\x1B[0m\n");
    va_end(args);

    return result;
}

/**
 * Print warning message wrapper
 */
int printf_warning(const char* format, ...) {
    va_list args;
    va_start(args, format);
    printf("\x1B[93m[Warning] ");
    int result = vprintf(format, args);
    printf(".\x1B[0m\n");
    va_end(args);

    return result;
}

/**
 * Print verbose text (if verbosity is enabled) wrapper
 */
int printf_verbose(bool enabled, const char* format, ...) {
    va_list args;
    va_start(args, format);
    int result = 0;
    if (enabled) {
        printf("\x1B[37m[Verbose] ");
        result = vprintf(format, args);
        printf("\x1B[0m\n");
    }
    va_end(args);

    return result;
}

/**
 * Print success message wrapper
 */
int printf_success(const char* format, ...) {
    va_list args;
    va_start(args, format);
    printf("\x1B[92m[Success] ");
    int result = vprintf(format, args);
    printf("\x1B[0m\n");
    va_end(args);

    return result;
}

/**
 * Print info message wrapper
 */
int printf_info(const char* format, ...) {
    va_list args;
    va_start(args, format);
    printf("\x1B[96m[Info] ");
    int result = vprintf(format, args);
    printf("\x1B[0m\n");
    va_end(args);

    return result;
}